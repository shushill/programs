# json

```cpp
using json = basic_json<>;
```
